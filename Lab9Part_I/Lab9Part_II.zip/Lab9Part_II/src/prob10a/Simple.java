package prob10a;

public class Simple {
	boolean flag = false;
	Simple(boolean f) {
		flag = f;
	}
}
